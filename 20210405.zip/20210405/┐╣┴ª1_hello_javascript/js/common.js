// alert('hello javascript');
// console.log('hello javascript');
// alert('"안녕하세요."\n사이트 점검 중입니다.\n불편을 드려서 죄송합니다.');//줄바꿈
// alert("총 인원은 "+(5+2)+"명입니다.");//문자 자료형 과 숫자 자료형의 차이
// console.log(true > false);// true == 1, false == 0 그래서 true > false 는 true 반환된다.
// console.log('가위' > '바위');// 한글 아스키코드로 비교연산
// console.log( 30 > 20 > 10 );// 30>20 먼저 계산 후 true 반환,true는 1이기때문에 1 > 10 결괏값은  false
/*
if 가정문, 조건문 표기방법
조건문이 true일 실행
예)
if (점심시간) { 밥을 먹는다. }
if(가정문,조건문){
실행문
}
*/
// if(true){
//   console.log('오늘은 월요일입니다.');
// }else{
//   console.log('오늘은 월요일이 아닙니다.');
// }

if( 300 > 50 ){
  alert("300은 50보다 큽니다.");
  alert("정답입니다.");
}
